import React, {useContext} from 'react';
import {Text, View, StyleSheet, FlatList, TouchableOpacity} from 'react-native';
import { Context } from '../context/BlogContext';
import { AntDesign } from '@expo/vector-icons';
import { Feather } from '@expo/vector-icons'

const IndexScreen = ({navigation}) => {
    const {state, deleteBlogPost} = useContext(Context);
    return (
        <View>           
            <FlatList 
                data = {state}
                keyExtractor = {blogPost => blogPost.title}
                renderItem = {({item}) => {
                    return (
                        <TouchableOpacity onPress = {() => navigation.navigate('Show', { id: item.id })}>
                            <View style = {styles.view}>
                                <Text style = {styles.text}>{item.title}-{item.id}</Text>
                                <TouchableOpacity onPress={() => deleteBlogPost(item.id)}>
                                 <AntDesign style={styles.icon} name="delete"/>
                                </TouchableOpacity>
                            </View>
                        </TouchableOpacity>
                    );
                }}
            />
        </View>
    );
};

IndexScreen.navigationOptions = ({navigation}) => {
    return {
        headerRight: () => (
            <TouchableOpacity onPress={() => navigation.navigate('Create')}>
                <Feather style = {styles.plusIcon} name="plus" size={35} />
            </TouchableOpacity>
        )    
    };
};

const styles = StyleSheet.create({
    view: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: 10,
        paddingVertical: 20,
        borderTopWidth: 1,
        borderColor: 'gray'
    },
    text: {
        fontSize: 24,
        marginLeft: 5
    },
    icon:{
        fontSize: 25,
        color: 'red'
    },
    plusIcon: {
        marginRight: 10,
        color: 'blue'
    }
});

export default IndexScreen;